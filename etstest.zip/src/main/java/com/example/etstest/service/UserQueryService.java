package com.example.etstest.service;

import com.example.etstest.model.User;

import java.util.List;

public interface UserQueryService {

    List<User> getAllUsers();
}
